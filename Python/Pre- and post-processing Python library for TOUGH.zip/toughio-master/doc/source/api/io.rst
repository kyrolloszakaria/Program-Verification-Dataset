Input and output files
======================

Input parameters
----------------

.. autofunction:: toughio.read_input

.. autofunction:: toughio.write_input

.. autofunction:: toughio.register_input


Simulation outputs
------------------

.. autofunction:: toughio.read_output

.. autofunction:: toughio.read_table

.. autofunction:: toughio.write_h5

.. autofunction:: toughio.write_output

.. autofunction:: toughio.register_output
