Command line programs
=====================

CO2TAB
------

.. argparse::
   :ref: toughio._cli._co2tab._get_parser
   :prog: toughio-co2tab


Export
------

.. argparse::
   :ref: toughio._cli._export._get_parser
   :prog: toughio-export


Extract
-------

.. argparse::
   :ref: toughio._cli._extract._get_parser
   :prog: toughio-extract


Merge
-----

.. argparse::
   :ref: toughio._cli._merge._get_parser
   :prog: toughio-merge


SAVE2INCON
----------

.. argparse::
   :ref: toughio._cli._save2incon._get_parser
   :prog: toughio-save2incon
