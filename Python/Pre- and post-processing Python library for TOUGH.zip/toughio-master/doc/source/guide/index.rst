User Guide
==========

.. toctree::
   :titlesonly:
   :maxdepth: 2

   installation
   input
