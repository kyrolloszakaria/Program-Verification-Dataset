Examples
========

This gallery contains different sample problems to demonstrate :mod:`toughio` pre- and post-processing capabilities.