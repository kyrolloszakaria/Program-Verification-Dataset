from ._write import write

__all__ = [
    "write",
]
