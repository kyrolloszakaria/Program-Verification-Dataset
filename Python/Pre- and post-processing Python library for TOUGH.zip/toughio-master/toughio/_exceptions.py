class ReadError(Exception):
    pass
