---
name: Bug report
about: Report a problem/bug to help us improve

---

**Description of the problem**

<!--
Please be as detailed as you can when describing an issue. The more information
we have, the easier it will be for us to track this down.
-->



**Full code that generated the error**

<!--
Include any data files or inputs required to run the code. It really helps if
we can run the code on our own machines.
-->

```python
PASTE YOUR CODE HERE
```


**Full error message**

```
PASTE ERROR MESSAGE HERE
```



**System information**

* Operating system:
* Python installation (Anaconda, system, ETS):
* Version of Python:
* Version of this package:
